package com.example.memorina.memorygame;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    int[] cards = new int[]{1,4,6, 2,3,1, 5,4,2, 3,5,6};
    Button b1, b2;
    int opencards = 0;
    int countopencards = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void onClick(View v)
    {
        Button button = (Button) v;
        String tag = button.getTag().toString();
        int index = Integer.parseInt(tag);
        button.setText(Integer.toString(cards[index]));
        if (opencards == 2) {
            if(b1.getTag() != b2.getTag()){
            b1.setText("");
            b2.setText("");
            }
        else
            {
                b1.setEnabled(false);
                b2.setEnabled(false);
                countopencards++;
            }
                button.setText(Integer.toString(cards[index]));
                b1 = button;
                opencards--;
            }
        else 
            if (opencards%2 !=0){
                    opencards -= (opencards - opencards%2);
                }
            else
            {
                opencards -= (opencards-1);
            }
        else 
            if (opencards == 0)
            {
                button.setText(Integer.toString(cards[index]));
                b1 = button;
                opencards++;
            }
            else
                if(opencards == 1){
                    button.setText(Integer.toString(cards[index]));
                    b2 = button;
                    opencards ++;
                }
        }
    }
    if (countopencards == 12) {
            Toast toast = Toast.makeText(getApplicationContext(),
                    "Вы выиграли!", Toast.LENGTH_LONG);
            toast.show();
        }
    }
}
